
    document.getElementById("abbtn").onclick = function () {
        location.href = "#aboutblock";
    };

 document.getElementById("pbtn").onclick = function () {
        location.href = "#portfolioblock";
    };

 document.getElementById("contactbtn").onclick = function () {
        location.href = "#contact-block";
 }